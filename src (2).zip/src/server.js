const { ensureBearerToken } = require('./middlewares/EnsureBearerToken');
const { EXTERNAL_SERVER_URL } = require('./config/Env');
const cors = require('cors');

const express = require('express');
const app = express();
app.use(express.json());
app.use(cors());
const topMinerURL= "/api/admin/users/topMiners?page=0&size=10"
async function getTopMiners() {
    const token = await ensureBearerToken();
    const axios = require('axios');
    const response = await axios.get(`${EXTERNAL_SERVER_URL}${topMinerURL}`, {
        headers: { Authorization: `Bearer ${token}` },
    });
    return response.data;
}
app.get('/topMiners', async (req, res) => {
    try {
        const data = await getTopMiners();
        res.status(200).json(data);
    } catch (error) {
        console.error('Failed to fetch top miners:', error.message);
        res.status(500).json({ message: 'Failed to fetch top miners' });
    }
});

// Start the server
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});