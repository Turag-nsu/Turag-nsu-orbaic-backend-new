const { login } = require('../services/AuthService');

let token = null;

// const ensureBearerToken = async () => {
//     if (!token) {
//         token = await login();
//     }
//     return token;
// }
async function ensureBearerToken() {
    if (!token) {
        console.log('Token is not available. Fetching a new token...');
        token = await login();
    }
    return token;
}

module.exports = {
    ensureBearerToken
};